# Bibliografia para aula 01.

* Slides e guião disponibilizados nesta pasta.
* [1, capítulo 1](https://elearning.ua.pt/mod/lti/view.php?id=1139979)
(Semelhante a [2, capítulo 1]).

# Trabalho para casa (Homework)

Ler e resolver os exercícios referentes a esta aula do livro recomendado [1].

[1] [Python for Everybody - Interactive]

[2] [Think Python 2e](http://greenteapress.com/wp/think-python-2e/)

